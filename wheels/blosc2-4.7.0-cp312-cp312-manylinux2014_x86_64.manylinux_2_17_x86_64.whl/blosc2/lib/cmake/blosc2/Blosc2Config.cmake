# only add PUBLIC dependencies as well
#   https://cmake.org/cmake/help/latest/manual/cmake-packages.7.html#creating-a-package-configuration-file
include(CMakeFindDependencyMacro)

# Search in <PackageName>_ROOT:
#   https://cmake.org/cmake/help/v3.12/policy/CMP0074.html
if(POLICY CMP0074)
    cmake_policy(SET CMP0074 NEW)
endif()

# locate the installed FindABC.cmake modules
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}/Modules")

# this section stores which configuration options were set
set(HAVE_THREADS ON)
set(HAVE_IPP )
set(HAVE_LZ4_CONFIG )
set(HAVE_ZLIB_NG TRUE)
set(HAVE_ZLIB_NG_CONFIG )
set(HAVE_ZSTD_CONFIG )
set(DEACTIVATE_IPP )
set(DEACTIVATE_ZLIB OFF)
set(DEACTIVATE_ZSTD OFF)
set(PREFER_EXTERNAL_LZ4 OFF)
set(PREFER_EXTERNAL_ZLIB OFF)
set(PREFER_EXTERNAL_ZSTD OFF)
set(BLOSC_DEPENDENCY_MODE "BUNDLED")
set(HAVE_ZFP TRUE)
set(BLOSC_ZFP_PROVIDER "BUNDLED")
set(LZ4_FETCHED TRUE)
set(ZLIB_NG_FETCHED TRUE)
set(ZSTD_FETCHED TRUE)

# find dependencies and their targets, which are used in our Blosc2Targets.cmake
#   additionally, the Blosc2_..._FOUND variables are used to support
#   find_package(Blosc2 ... COMPONENTS ... ...)
#   this enables downstream projects to express the need for specific features.
set(CMAKE_THREAD_PREFER_PTHREAD TRUE) # pre 3.1
set(THREADS_PREFER_PTHREAD_FLAG TRUE) # CMake 3.1+
if(HAVE_THREADS)
    find_dependency(Threads)
    set(Blosc2_THREADS_FOUND TRUE)
else()
    set(Blosc2_THREADS_FOUND FALSE)
endif()

if(NOT DEACTIVATE_IPP AND HAVE_IPP)
    find_dependency(IPP)
    set(Blosc2_IPP_FOUND FALSE)
else()
    set(Blosc2_IPP_FOUND TRUE)
endif()

if(NOT LZ4_FETCHED)
    if(HAVE_LZ4_CONFIG)
        find_dependency(lz4 CONFIG)
    else()
        find_dependency(LZ4 MODULE)
    endif()
endif()
set(Blosc2_LZ4_FOUND TRUE)

if(DEACTIVATE_ZLIB)
    set(Blosc2_ZLIB_FOUND FALSE)
elseif(ZLIB_NG_FETCHED)
    set(Blosc2_ZLIB_FOUND TRUE)
else()
    if(HAVE_ZLIB_NG)
        if(HAVE_ZLIB_NG_CONFIG)
            find_dependency(zlib-ng CONFIG)
        else()
            find_dependency(ZLIB_NG MODULE)
        endif()
    else()
        find_dependency(ZLIB)
    endif()
    set(Blosc2_ZLIB_FOUND TRUE)
endif()

if(DEACTIVATE_ZSTD)
    set(Blosc2_ZSTD_FOUND FALSE)
elseif(ZSTD_FETCHED)
    set(Blosc2_ZSTD_FOUND TRUE)
else()
    if(HAVE_ZSTD_CONFIG)
        find_dependency(zstd CONFIG)
    else()
        find_dependency(ZSTD MODULE)
    endif()
    set(Blosc2_ZSTD_FOUND TRUE)
endif()

if(HAVE_ZFP)
    set(Blosc2_ZFP_FOUND TRUE)
    if(BLOSC_ZFP_PROVIDER STREQUAL "EXTERNAL")
        find_package(zfp CONFIG QUIET)
        if(NOT zfp_FOUND)
            find_package(ZFP CONFIG QUIET)
        endif()
        if(NOT zfp_FOUND AND NOT ZFP_FOUND)
            find_dependency(ZFP MODULE)
        endif()
        set(BLOSC_ZFP_TARGET "")
        foreach(BLOSC_ZFP_CANDIDATE zfp ZFP::zfp zfp::zfp ZFP::ZFP)
            if(TARGET ${BLOSC_ZFP_CANDIDATE} AND NOT BLOSC_ZFP_TARGET)
                set(BLOSC_ZFP_TARGET ${BLOSC_ZFP_CANDIDATE})
            endif()
        endforeach()
        if(BLOSC_ZFP_TARGET AND NOT TARGET zfp)
            add_library(zfp INTERFACE IMPORTED)
            target_link_libraries(zfp INTERFACE ${BLOSC_ZFP_TARGET})
        endif()
    endif()
else()
    set(Blosc2_ZFP_FOUND FALSE)
endif()

# define central Blosc2::blosc2_shared/static targets
include("${CMAKE_CURRENT_LIST_DIR}/Blosc2Targets.cmake")

# check if components are fulfilled and set Blosc2_<COMPONENT>_FOUND vars
#   Blosc2_FIND_COMPONENTS is a list set by find_package(... COMPONENTS ... ...)
#   likewise Blosc2_FIND_REQUIRED_... per component specified
foreach(comp ${Blosc2_FIND_COMPONENTS})
    if(NOT Blosc2_${comp}_FOUND)
        if(Blosc2_FIND_REQUIRED_${comp})
            set(Blosc2_FOUND FALSE)
        endif()
    endif()
endforeach()

# Defines imported targets for Blosc2 inside a Python wheel

# ------------------------------
# Shared library target
# ------------------------------
if(NOT TARGET Blosc2::blosc2_shared)
  add_library(Blosc2::blosc2_shared SHARED IMPORTED GLOBAL)

  if(WIN32)
    # MSVC: import library (.lib) + runtime DLL (.dll)
    set_target_properties(Blosc2::blosc2_shared PROPERTIES
      IMPORTED_IMPLIB "${CMAKE_CURRENT_LIST_DIR}/../blosc2_shared.lib"
      IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../blosc2_shared.dll"
      INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../../include"
    )
  else()
    # Linux/macOS
    set_target_properties(Blosc2::blosc2_shared PROPERTIES
      IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../blosc2_shared.so"
      INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../../include"
    )
  endif()
endif()

# ------------------------------
# Static library target
# ------------------------------
if(NOT TARGET Blosc2::blosc2_static)
  add_library(Blosc2::blosc2_static STATIC IMPORTED GLOBAL)

  if(MSVC)
    # Windows static library uses .lib
    set_target_properties(Blosc2::blosc2_static PROPERTIES
      IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../blosc2_static.lib"
      INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../../include"
    )
  else()
    # Linux/macOS static library uses .a
    set_target_properties(Blosc2::blosc2_static PROPERTIES
      IMPORTED_LOCATION "${CMAKE_CURRENT_LIST_DIR}/../blosc2_static.a"
      INTERFACE_INCLUDE_DIRECTORIES "${CMAKE_CURRENT_LIST_DIR}/../../include"
    )
  endif()
endif()

